import React from 'react';
import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';
import CursorGlow from './CursorGlow';

export default function Layout() {
  return (
    <div className="relative min-h-screen overflow-x-hidden bg-[#0A0A0F] text-white">
      {/* Ambient gradient background */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="animate-float absolute -left-32 top-0 h-[500px] w-[500px] rounded-full bg-blue-600/10 blur-[120px]" />
        <div className="animate-float absolute right-0 top-1/3 h-[400px] w-[400px] rounded-full bg-purple-600/10 blur-[100px] [animation-delay:2s]" />
        <div className="animate-float absolute bottom-0 left-1/3 h-[450px] w-[450px] rounded-full bg-pink-600/8 blur-[110px] [animation-delay:4s]" />
      </div>

      <CursorGlow />
      <Navbar />

      <main className="relative z-10">
        <Outlet />
      </main>

      <Footer />
    </div>
  );
}