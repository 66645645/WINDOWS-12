import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, X, Check, Ban, Download } from 'lucide-react';
import { isDownloadDisabled, setDownloadDisabled } from '@/lib/downloadStatus';

const ADMIN_CODE = 'XAML';

export default function AdminPanel() {
  const [open, setOpen] = useState(false);
  const [code, setCode] = useState('');
  const [unlocked, setUnlocked] = useState(false);
  const [error, setError] = useState('');
  const [disabled, setDisabled] = useState(false);

  const handleOpen = () => {
    setDisabled(isDownloadDisabled());
    setCode('');
    setUnlocked(false);
    setError('');
    setOpen(true);
  };

  const handleUnlock = () => {
    if (code.trim().toUpperCase() === ADMIN_CODE) {
      setUnlocked(true);
      setError('');
    } else {
      setError('Invalid admin code');
    }
  };

  const toggleDownloads = () => {
    const newState = !disabled;
    setDisabled(newState);
    setDownloadDisabled(newState);
  };

  return (
    <>
      <button
        onClick={handleOpen}
        className="text-[10px] text-zinc-700 transition-colors hover:text-zinc-400"
      >
        Admin
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 px-4 backdrop-blur-md"
            onClick={() => setOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.92, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.92, opacity: 0, y: 10 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
              className="glass-card relative w-full max-w-sm overflow-hidden rounded-2xl p-8"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Glow accents */}
              <div className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-purple-600/20 blur-3xl" />
              <div className="pointer-events-none absolute -bottom-16 -left-16 h-40 w-40 rounded-full bg-pink-600/15 blur-3xl" />

              {/* Close */}
              <button
                onClick={() => setOpen(false)}
                className="absolute right-4 top-4 z-10 text-zinc-500 transition-colors hover:text-white"
              >
                <X size={18} />
              </button>

              {/* Header */}
              <div className="relative text-center">
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 shadow-lg shadow-purple-500/30">
                  <Shield size={24} className="text-white" />
                </div>
                <h2 className="text-xl font-bold text-white">Admin Panel</h2>
              </div>

              {!unlocked ? (
                <div className="relative mt-6">
                  <p className="text-center text-sm text-zinc-400">
                    Enter the admin access code to manage downloads.
                  </p>
                  {error && (
                    <div className="mt-4 rounded-lg border border-red-500/20 bg-red-500/10 p-3 text-center text-sm text-red-400">
                      {error}
                    </div>
                  )}
                  <input
                    type="password"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleUnlock()}
                    placeholder="Admin code"
                    className="mt-4 w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white placeholder-zinc-600 transition-colors focus:border-purple-500/50 focus:outline-none"
                    autoFocus
                  />
                  <button
                    onClick={handleUnlock}
                    disabled={!code}
                    className="gradient-bg mt-4 w-full rounded-xl py-3 text-sm font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-40"
                  >
                    Unlock
                  </button>
                </div>
              ) : (
                <div className="relative mt-6">
                  <p className="text-center text-sm text-zinc-400">
                    Manage Windows 12 download availability.
                  </p>

                  {/* Toggle card */}
                  <div className="mt-6 rounded-xl border border-white/10 bg-white/[0.02] p-5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div
                          className={`flex h-10 w-10 items-center justify-center rounded-xl ${
                            disabled
                              ? 'bg-red-500/15 text-red-400'
                              : 'bg-green-500/15 text-green-400'
                          }`}
                        >
                          {disabled ? <Ban size={18} /> : <Download size={18} />}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-white">Downloads</p>
                          <p className="mt-0.5 text-xs text-zinc-500">
                            {disabled ? 'Disabled — blocked for all users' : 'Enabled — available to all'}
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={toggleDownloads}
                        className={`relative h-7 w-12 flex-shrink-0 rounded-full transition-colors duration-300 ${
                          disabled ? 'bg-red-500/40' : 'bg-green-500/40'
                        }`}
                      >
                        <motion.div
                          layout
                          transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                          className={`absolute top-1 h-5 w-5 rounded-full shadow-md ${
                            disabled
                              ? 'left-1 bg-red-400'
                              : 'left-6 bg-green-400'
                          }`}
                        />
                      </button>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-center gap-2 text-xs text-zinc-500">
                    <Check size={14} className="text-green-400" />
                    Admin access verified
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}