const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, LogOut, UserCircle } from 'lucide-react';
import WindowsLogo from './WindowsLogo';
import { useAuth } from '@/lib/AuthContext';

export default function Navbar() {
  const location = useLocation();
  const { isAuthenticated, user } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const isGuest =
    typeof window !== 'undefined' && localStorage.getItem('win12_guest') === 'true';

  const handleSignIn = () => {
    localStorage.removeItem('win12_guest');
    window.location.href = '/';
  };

  const handleSignOut = () => {
    localStorage.removeItem('win12_guest');
    db.auth.logout('/');
  };

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const links = [
    { to: '/', label: 'Home' },
    { to: '/download', label: 'Download' },
  ];

  return (
    <motion.nav
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="fixed top-4 left-1/2 z-50 w-[calc(100%-2rem)] max-w-5xl -translate-x-1/2"
    >
      <div
        className={`flex items-center justify-between rounded-2xl border px-4 py-3 transition-all duration-300 md:px-6 ${
          scrolled
            ? 'border-white/15 bg-[#0A0A0F]/80 backdrop-blur-2xl'
            : 'border-white/10 bg-white/[0.03] backdrop-blur-xl'
        }`}
      >
        <Link to="/" className="flex items-center gap-2.5" onClick={() => setMobileOpen(false)}>
          <WindowsLogo size={28} />
          <div className="flex flex-col leading-none">
            <span className="text-sm font-bold tracking-tight text-white">Windows 12</span>
            <span className="text-[10px] text-zinc-500">Unofficial</span>
          </div>
        </Link>

        {/* Center: Nav links */}
        <div className="hidden items-center gap-1 md:flex">
          {links.map((link) => {
            const isActive = location.pathname === link.to;
            return (
              <Link key={link.to} to={link.to} className="relative px-4 py-2">
                <span
                  className={`text-sm font-medium transition-colors ${
                    isActive ? 'text-white' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {link.label}
                </span>
                {isActive && (
                  <motion.div
                    layoutId="nav-indicator"
                    className="absolute -bottom-0.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-pink-500 shadow-[0_0_8px_rgba(236,72,153,0.8)]"
                  />
                )}
              </Link>
            );
          })}
        </div>

        {/* Right: Auth state */}
        <div className="hidden items-center gap-2 md:flex">
          {isAuthenticated ? (
            <>
              <span className="hidden items-center gap-1.5 text-xs text-zinc-400 lg:flex">
                <UserCircle size={15} className="text-purple-400" />
                {user?.email?.split('@')[0] || 'Account'}
              </span>
              <button
                onClick={handleSignOut}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-white transition-transform hover:scale-105"
                title="Sign Out"
              >
                <LogOut size={15} />
              </button>
            </>
          ) : isGuest ? (
            <>
              <span className="text-xs font-medium text-zinc-500">Guest</span>
              <button
                onClick={handleSignIn}
                className="rounded-lg border border-purple-500/30 bg-purple-500/10 px-4 py-2 text-sm font-semibold text-purple-300 transition-colors hover:bg-purple-500/20"
              >
                Sign In
              </button>
            </>
          ) : null}
        </div>

        {/* Mobile toggle */}
        <button
          className="text-white md:hidden"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Menu"
        >
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-2 flex flex-col gap-1 rounded-2xl border border-white/10 bg-[#0A0A0F]/95 p-3 backdrop-blur-2xl md:hidden"
          >
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setMobileOpen(false)}
                className={`rounded-lg px-4 py-3 text-sm font-medium transition-colors ${
                  location.pathname === link.to
                    ? 'bg-white/5 text-white'
                    : 'text-zinc-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                {link.label}
              </Link>
            ))}
            {isAuthenticated ? (
              <button
                onClick={() => {
                  handleSignOut();
                  setMobileOpen(false);
                }}
                className="flex items-center gap-2 rounded-lg px-4 py-3 text-sm font-medium text-zinc-400 transition-colors hover:bg-white/5 hover:text-white"
              >
                <LogOut size={16} />
                Sign Out
              </button>
            ) : isGuest ? (
              <div className="flex items-center justify-between rounded-lg px-4 py-3">
                <span className="text-sm font-medium text-zinc-500">Guest</span>
                <button
                  onClick={() => {
                    handleSignIn();
                    setMobileOpen(false);
                  }}
                  className="rounded-lg bg-purple-500/10 px-4 py-2 text-sm font-semibold text-purple-300"
                >
                  Sign In
                </button>
              </div>
            ) : null}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}