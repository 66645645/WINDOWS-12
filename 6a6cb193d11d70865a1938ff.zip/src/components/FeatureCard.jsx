import React from 'react';
import { motion } from 'framer-motion';

export default function FeatureCard({ icon: Icon, title, subtitle, description, accent, index = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.6, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
      className="glass-card group relative overflow-hidden rounded-2xl p-8 transition-all duration-300 hover:bg-white/[0.06] hover:border-white/20"
    >
      {/* Gradient glow on hover */}
      <div
        className={`absolute -right-16 -top-16 h-40 w-40 rounded-full bg-gradient-to-br ${accent} opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-25`}
      />

      {/* Icon */}
      <div
        className={`relative mb-6 inline-flex rounded-xl bg-gradient-to-br ${accent} p-3 shadow-lg`}
      >
        <Icon className="h-6 w-6 text-white" strokeWidth={2} />
      </div>

      <p className="text-xs font-medium uppercase tracking-wider text-zinc-500">{subtitle}</p>
      <h3 className="mt-1.5 text-2xl font-bold text-white">{title}</h3>
      <p className="mt-3 text-[15px] leading-relaxed text-zinc-400">{description}</p>
    </motion.div>
  );
}