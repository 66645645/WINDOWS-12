import React from 'react';

export default function WindowsLogo({ size = 120, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      className={className}
      style={{ filter: 'drop-shadow(0 0 20px rgba(139, 92, 246, 0.35))' }}
    >
      <defs>
        <linearGradient id="paneTL" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#D69DFE" />
          <stop offset="100%" stopColor="#B893F7" />
        </linearGradient>
        <linearGradient id="paneTR" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#B893F7" />
          <stop offset="100%" stopColor="#9B7AE8" />
        </linearGradient>
        <linearGradient id="paneBL" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#C0A1F9" />
          <stop offset="100%" stopColor="#7B8FF0" />
        </linearGradient>
        <linearGradient id="paneBR" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#7B8FF0" />
          <stop offset="100%" stopColor="#4E8BFD" />
        </linearGradient>
      </defs>
      <rect x="3" y="3" width="43" height="43" rx="5" fill="url(#paneTL)" />
      <rect x="54" y="3" width="43" height="43" rx="5" fill="url(#paneTR)" />
      <rect x="3" y="54" width="43" height="43" rx="5" fill="url(#paneBL)" />
      <rect x="54" y="54" width="43" height="43" rx="5" fill="url(#paneBR)" />
    </svg>
  );
}