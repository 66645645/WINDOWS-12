import React, { useEffect } from 'react';
import { motion, useMotionValue, useSpring } from 'framer-motion';

export default function CursorGlow() {
  const x = useMotionValue(-1000);
  const y = useMotionValue(-1000);
  const springX = useSpring(x, { stiffness: 80, damping: 25 });
  const springY = useSpring(y, { stiffness: 80, damping: 25 });

  useEffect(() => {
    const handleMouseMove = (e) => {
      x.set(e.clientX - 300);
      y.set(e.clientY - 300);
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [x, y]);

  return (
    <motion.div
      className="pointer-events-none fixed z-0 hidden h-[600px] w-[600px] rounded-full md:block"
      style={{
        x: springX,
        y: springY,
        background:
          'radial-gradient(circle, rgba(139,92,246,0.07) 0%, rgba(74,144,217,0.04) 35%, rgba(236,72,153,0.02) 60%, transparent 75%)',
      }}
    />
  );
}