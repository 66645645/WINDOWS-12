import React from 'react';
import { Link } from 'react-router-dom';
import WindowsLogo from './WindowsLogo';
import AdminPanel from './AdminPanel';

export default function Footer() {
  return (
    <footer className="relative z-10 overflow-hidden border-t border-white/10 bg-gradient-to-b from-transparent to-[#0A0A0F]">
      <div className="absolute inset-0 bg-gradient-to-b from-violet-950/10 to-transparent" />
      <div className="relative mx-auto max-w-6xl px-4 py-16 md:px-8">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <Link to="/" className="flex items-center gap-2.5">
              <WindowsLogo size={32} />
              <div className="flex flex-col leading-none">
                <span className="text-base font-bold text-white">Windows 12</span>
                <span className="text-[11px] text-zinc-500">Unofficial Concept</span>
              </div>
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-zinc-500">
              A conceptual vision of what the next generation of Windows could be. Reimagining
              computing through AI, beauty, and flow.
            </p>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
              Navigate
            </h4>
            <ul className="mt-4 space-y-3">
              <li>
                <Link to="/" className="text-sm text-zinc-500 transition-colors hover:text-white">
                  Home
                </Link>
              </li>
              <li>
                <Link
                  to="/download"
                  className="text-sm text-zinc-500 transition-colors hover:text-white"
                >
                  Download
                </Link>
              </li>
              <li>
                <a
                  href="#features"
                  className="text-sm text-zinc-500 transition-colors hover:text-white"
                >
                  Features
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
              Legal
            </h4>
            <ul className="mt-4 space-y-3">
              <li>
                <a href="#" className="text-sm text-zinc-500 transition-colors hover:text-white">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-zinc-500 transition-colors hover:text-white">
                  Terms of Use
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-zinc-500 transition-colors hover:text-white">
                  Disclaimer
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-white/5 pt-6">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <p className="text-sm text-zinc-500">
              Created by <span className="gradient-text font-semibold">Leo Mancrief</span>
            </p>
            <AdminPanel />
          </div>
          <p className="mt-4 text-xs leading-relaxed text-zinc-600">
            © 2026 Windows 12 Concept. This is an unofficial, non-commercial concept project and
            is not affiliated with, endorsed by, or connected to Microsoft Corporation. Windows is a
            trademark of Microsoft Corporation. All product names, logos, and brands are property of
            their respective owners.
          </p>
        </div>
      </div>
    </footer>
  );
}