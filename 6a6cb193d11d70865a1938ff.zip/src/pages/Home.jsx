import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Sparkles,
  Layers,
  Zap,
  Gamepad2,
  ShieldCheck,
  LayoutGrid,
  ArrowRight,
} from 'lucide-react';
import Hero from '@/components/Hero';
import FeatureCard from '@/components/FeatureCard';

const features = [
  {
    icon: Sparkles,
    title: 'Windows Copilot+',
    subtitle: 'AI Integration',
    description:
      'Your AI companion woven into every layer of the OS. Contextual assistance, intelligent search, and predictive workflows that adapt to how you work.',
    accent: 'from-blue-500 to-violet-500',
  },
  {
    icon: Layers,
    title: 'Neo-Fluent UI',
    subtitle: 'Redesigned Interface',
    description:
      'Liquid glass surfaces with refractive light and depth. A design language that blurs the boundary between digital and physical, creating a living desktop.',
    accent: 'from-violet-500 to-fuchsia-500',
  },
  {
    icon: Zap,
    title: 'Quantum Performance',
    subtitle: 'Speed & Efficiency',
    description:
      'Boot times under 3 seconds. 40% faster application launches. Kernel-level optimizations that squeeze every ounce of power from your hardware.',
    accent: 'from-fuchsia-500 to-pink-500',
  },
  {
    icon: Gamepad2,
    title: 'DirectX 13 Ultimate',
    subtitle: 'Gaming Redefined',
    description:
      'Ray-traced everything, auto-HDR across all titles, and DirectStorage that loads worlds instantly. Gaming has never looked or felt this immersive.',
    accent: 'from-blue-500 to-purple-500',
  },
  {
    icon: ShieldCheck,
    title: 'Sentinel Shield',
    subtitle: 'Security First',
    description:
      'Hardware-rooted security with zero-trust architecture. Windows Hello, TPM 2.0, and AI-powered threat detection that protects before threats emerge.',
    accent: 'from-violet-500 to-blue-500',
  },
  {
    icon: LayoutGrid,
    title: 'Living Start',
    subtitle: 'Adaptive Menu',
    description:
      'An AI-curated Start menu that learns your rhythm. Contextually aware, beautifully animated, and always one step ahead of what you need.',
    accent: 'from-pink-500 to-violet-500',
  },
];

const stats = [
  { value: '3s', label: 'Boot Time' },
  { value: '40%', label: 'Faster Launches' },
  { value: '100%', label: 'AI-Native' },
  { value: '∞', label: 'Possibilities' },
];

export default function Home() {
  return (
    <>
      <Hero />

      {/* Features Section */}
      <section id="features" className="relative px-4 py-24 md:py-32">
        <div className="mx-auto max-w-6xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="mx-auto max-w-2xl text-center"
          >
            <p className="text-sm font-medium uppercase tracking-wider text-purple-400">
              What's New
            </p>
            <h2 className="mt-3 text-4xl font-black tracking-tight text-white md:text-5xl">
              Built for what comes next
            </h2>
            <p className="mt-4 text-lg text-zinc-400">
              Every pixel, every interaction, and every millisecond has been reimagined. Windows 12
              isn't an update — it's a rebirth.
            </p>
          </motion.div>

          <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, i) => (
              <FeatureCard key={feature.title} {...feature} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Stats Banner */}
      <section className="relative border-y border-white/10 bg-white/[0.02]">
        <div className="mx-auto grid max-w-5xl grid-cols-2 gap-8 px-4 py-16 md:grid-cols-4 md:py-20">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="text-center"
            >
              <div className="gradient-text text-4xl font-black md:text-5xl">{stat.value}</div>
              <div className="mt-2 text-sm text-zinc-500">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative px-4 py-24 md:py-32">
        <div className="mx-auto max-w-4xl">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="glass-card relative overflow-hidden rounded-3xl px-8 py-16 text-center md:px-16 md:py-20"
          >
            <div className="absolute -left-20 -top-20 h-60 w-60 rounded-full bg-purple-600/20 blur-3xl" />
            <div className="absolute -bottom-20 -right-20 h-60 w-60 rounded-full bg-pink-600/20 blur-3xl" />

            <div className="relative">
              <h2 className="text-3xl font-black tracking-tight text-white md:text-5xl">
                Ready to experience
                <br />
                <span className="gradient-text animate-gradient">the future of Windows?</span>
              </h2>
              <p className="mx-auto mt-5 max-w-xl text-lg text-zinc-400">
                Download the Windows 12 concept build today and step into the next era of computing.
              </p>
              <Link to="/download" className="mt-8 inline-block">
                <button className="gradient-bg animate-pulse-glow group flex items-center gap-2.5 rounded-xl px-8 py-4 text-base font-semibold text-white transition-transform hover:scale-105">
                  Download Windows 12
                  <ArrowRight
                    size={18}
                    className="transition-transform group-hover:translate-x-1"
                  />
                </button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
}