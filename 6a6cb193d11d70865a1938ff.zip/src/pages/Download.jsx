import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Download as DownloadIcon,
  CheckCircle2,
  Cpu,
  HardDrive,
  Monitor,
  Globe,
  ShieldCheck,
  Clock,
  Lock,
  Ban,
} from 'lucide-react';
import WindowsLogo from '@/components/WindowsLogo';
import { useAuth } from '@/lib/AuthContext';
import { isDownloadDisabled } from '@/lib/downloadStatus';

const systemRequirements = [
  {
    icon: Cpu,
    label: 'Processor',
    value: '1 GHz or faster, 2+ cores',
  },
  {
    icon: HardDrive,
    label: 'Storage',
    value: '64 GB minimum',
  },
  {
    icon: Monitor,
    label: 'Display',
    value: '720p, 9" or larger',
  },
  {
    icon: ShieldCheck,
    label: 'Firmware',
    value: 'UEFI, Secure Boot, TPM 2.0',
  },
];

const specs = [
  { label: 'Version', value: '12.0.1 (Concept Build)' },
  { label: 'Architecture', value: 'x64 / ARM64' },
  { label: 'File Size', value: '4.8 GB' },
  { label: 'Language', value: 'Multi-language' },
  { label: 'License', value: 'Unofficial Concept' },
  { label: 'Released', value: '2026' },
];

export default function Download() {
  const [status, setStatus] = useState('idle'); // idle | downloading | done
  const { isAuthenticated } = useAuth();

  // Downloads disabled by admin — show disabled message to everyone
  if (isDownloadDisabled()) {
    return (
      <section className="relative flex min-h-screen flex-col items-center justify-center px-4 pt-28 pb-16">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute left-1/2 top-1/2 h-[700px] w-[700px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-br from-red-600/12 via-purple-600/12 to-pink-600/12 blur-[120px]" />
        </div>
        <div className="relative z-10 w-full max-w-md text-center">
          <div className="glass-card rounded-3xl p-10">
            <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-red-500 to-purple-500 shadow-lg shadow-red-500/20">
              <Ban size={28} className="text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">Downloads temporarily disabled</h2>
            <p className="mt-3 text-zinc-400">
              The host has disabled Windows downloads for a short moment. Please check back later.
            </p>
          </div>
        </div>
      </section>
    );
  }

  // Guests cannot download — show sign-in prompt instead
  if (!isAuthenticated) {
    const handleSignIn = () => {
      localStorage.removeItem('win12_guest');
      window.location.href = '/';
    };

    return (
      <section className="relative flex min-h-screen flex-col items-center justify-center px-4 pt-28 pb-16">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute left-1/2 top-1/2 h-[700px] w-[700px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-br from-blue-600/12 via-purple-600/12 to-pink-600/12 blur-[120px]" />
        </div>
        <div className="relative z-10 w-full max-w-md text-center">
          <div className="glass-card rounded-3xl p-10">
            <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-purple-500 shadow-lg shadow-purple-500/20">
              <Lock size={28} className="text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">Sign in to download</h2>
            <p className="mt-3 text-zinc-400">
              You're browsing as a guest. Create an account or sign in to download Windows 12.
            </p>
            <button
              onClick={handleSignIn}
              className="gradient-bg mt-6 flex w-full items-center justify-center gap-2 rounded-xl px-6 py-3.5 text-base font-semibold text-white transition-transform hover:scale-105"
            >
              Sign In or Create Account
            </button>
          </div>
        </div>
      </section>
    );
  }

  const handleDownload = () => {
    if (status === 'downloading') return;
    setStatus('downloading');

    setTimeout(() => {
      const content = `WINDOWS 12 — UNOFFICIAL CONCEPT BUILD
============================================

No application has been downloaded.

The actual installer (.exe) will be provided when available.
This is a placeholder file confirming your download request.

--------------------------------------------
Build:     12.0.1 (Concept)
Date:      2026
Status:    Placeholder — No executable attached
License:   Unofficial Concept Project
--------------------------------------------

Thank you for your interest in Windows 12 (Unofficial).

This is a non-commercial concept project and is not affiliated
with, endorsed by, or connected to Microsoft Corporation.
Windows is a trademark of Microsoft Corporation.
`;

      const blob = new Blob([content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Windows12_Installer.txt';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setStatus('done');
      setTimeout(() => setStatus('idle'), 5000);
    }, 2500);
  };

  return (
    <section className="relative flex min-h-screen flex-col items-center justify-center px-4 pt-28 pb-16">
      {/* Background glow */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-1/2 h-[700px] w-[700px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-br from-blue-600/12 via-purple-600/12 to-pink-600/12 blur-[120px]" />
      </div>

      <div className="relative z-10 w-full max-w-3xl text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.div
            animate={{ y: [0, -6, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
            className="mb-8 flex justify-center"
          >
            <WindowsLogo size={90} className="drop-shadow-[0_0_40px_rgba(139,92,246,0.4)]" />
          </motion.div>

          <h1 className="gradient-text animate-gradient text-4xl font-black tracking-tight md:text-6xl">
            Download Windows 12
          </h1>
          <p className="mt-3 text-xs font-medium uppercase tracking-[0.3em] text-zinc-600">
            Unofficial Concept Build
          </p>
          <p className="mx-auto mt-6 max-w-xl text-lg text-zinc-400">
            Experience the future of Windows today. Click below to start your download.
          </p>
        </motion.div>

        {/* Download Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-10 flex flex-col items-center"
        >
          <AnimatePresence mode="wait">
            {status === 'idle' && (
              <motion.button
                key="idle"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                onClick={handleDownload}
                className="gradient-bg animate-pulse-glow group flex items-center gap-3 rounded-2xl px-10 py-5 text-lg font-semibold text-white transition-transform hover:scale-105"
              >
                <DownloadIcon size={22} />
                Download Windows 12
              </motion.button>
            )}

            {status === 'downloading' && (
              <motion.div
                key="downloading"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="flex flex-col items-center gap-4"
              >
                <div className="relative flex h-16 w-16 items-center justify-center">
                  <div className="animate-spin-slow absolute inset-0 rounded-full border-4 border-white/10 border-t-purple-500" />
                  <DownloadIcon size={20} className="text-purple-400" />
                </div>
                <span className="text-sm text-zinc-400">Preparing download…</span>
              </motion.div>
            )}

            {status === 'done' && (
              <motion.div
                key="done"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="flex flex-col items-center gap-3"
              >
                <div className="flex items-center gap-2 rounded-2xl border border-green-500/20 bg-green-500/10 px-8 py-5">
                  <CheckCircle2 size={22} className="text-green-400" />
                  <span className="text-lg font-semibold text-white">Download started!</span>
                </div>
                <span className="text-sm text-zinc-500">Check your downloads folder</span>
              </motion.div>
            )}
          </AnimatePresence>

          <p className="mt-6 flex items-center gap-1.5 text-xs text-zinc-600">
            <Clock size={12} />
            Placeholder file — installer coming soon
          </p>
        </motion.div>

        {/* Technical Specs */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="glass-card mt-16 grid grid-cols-2 gap-px overflow-hidden rounded-2xl"
        >
          {specs.map((spec, i) => (
            <div
              key={spec.label}
              className={`bg-white/[0.01] p-5 text-left ${
                i % 2 === 0 ? 'border-r border-white/5' : ''
              } ${i < specs.length - 2 ? 'border-b border-white/5' : ''}`}
            >
              <p className="text-xs uppercase tracking-wider text-zinc-500">{spec.label}</p>
              <p className="mt-1 text-sm font-medium text-white">{spec.value}</p>
            </div>
          ))}
        </motion.div>

        {/* System Requirements */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-8"
        >
          <h3 className="mb-5 text-sm font-semibold uppercase tracking-wider text-zinc-400">
            Minimum System Requirements
          </h3>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {systemRequirements.map((req, i) => (
              <motion.div
                key={req.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.7 + i * 0.1 }}
                className="glass-card rounded-xl p-5 text-left"
              >
                <req.icon size={20} className="mb-3 text-purple-400" />
                <p className="text-xs uppercase tracking-wider text-zinc-500">{req.label}</p>
                <p className="mt-1 text-sm font-medium text-white">{req.value}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Disclaimer */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mx-auto mt-12 max-w-2xl text-xs leading-relaxed text-zinc-600"
        >
          This is an unofficial, non-commercial concept project and is not affiliated with,
          endorsed by, or connected to Microsoft Corporation. Windows is a trademark of Microsoft
          Corporation. The download contains a placeholder file — no actual software is included.
        </motion.p>
      </div>
    </section>
  );
}