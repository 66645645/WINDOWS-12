const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { motion } from 'framer-motion';

import { Mail, Lock, Loader2, ArrowLeft } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { toast } from '@/components/ui/use-toast';
import WindowsLogo from '@/components/WindowsLogo';
import GoogleIcon from '@/components/GoogleIcon';
import AppleIcon from '@/components/AppleIcon';

export default function Auth() {
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showOtp, setShowOtp] = useState(false);
  const [otpCode, setOtpCode] = useState('');

  const clearGuest = () => localStorage.removeItem('win12_guest');

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      clearGuest();
      await db.auth.loginViaEmailPassword(email, password);
      window.location.href = '/';
    } catch (err) {
      setError(err.message || 'Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError('');
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    setLoading(true);
    try {
      clearGuest();
      await db.auth.register({ email, password });
      setShowOtp(true);
    } catch (err) {
      setError(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setError('');
    setLoading(true);
    try {
      const result = await db.auth.verifyOtp({ email, otpCode });
      if (result?.access_token) {
        db.auth.setToken(result.access_token);
      }
      window.location.href = '/';
    } catch (err) {
      setError(err.message || 'Invalid verification code');
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setError('');
    try {
      await db.auth.resendOtp(email);
      toast({ title: 'Code sent', description: 'Check your email for the new code.' });
    } catch (err) {
      setError(err.message || 'Failed to resend code');
    }
  };

  const handleGoogle = () => {
    clearGuest();
    db.auth.loginWithProvider('google', '/');
  };

  const handleApple = () => {
    clearGuest();
    db.auth.loginWithProvider('apple', '/');
  };

  const handleGuest = () => {
    localStorage.setItem('win12_guest', 'true');
    window.location.href = '/';
  };

  // ===== OTP Step =====
  if (showOtp) {
    return (
      <AuthShell>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full">
          <div className="text-center">
            <div className="mb-3 flex justify-center">
              <WindowsLogo size={56} />
            </div>
            <h1 className="gradient-text text-2xl font-black tracking-tight">Verify your email</h1>
            <p className="mt-2 text-sm text-zinc-400">We sent a code to {email}</p>
          </div>

          {error && (
            <div className="mt-6 rounded-lg border border-red-500/20 bg-red-500/10 p-3 text-sm text-red-400">
              {error}
            </div>
          )}

          <div className="mt-6 flex justify-center">
            <InputOTP maxLength={6} value={otpCode} onChange={setOtpCode} autoFocus>
              <InputOTPGroup>
                <InputOTPSlot index={0} />
                <InputOTPSlot index={1} />
                <InputOTPSlot index={2} />
                <InputOTPSlot index={3} />
                <InputOTPSlot index={4} />
                <InputOTPSlot index={5} />
              </InputOTPGroup>
            </InputOTP>
          </div>

          <button
            onClick={handleVerify}
            disabled={loading || otpCode.length < 6}
            className="gradient-bg mt-6 flex w-full items-center justify-center gap-2 rounded-xl py-3 font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-40"
          >
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            {loading ? 'Verifying…' : 'Verify'}
          </button>

          <div className="mt-4 flex items-center justify-between text-sm">
            <button
              onClick={() => {
                setShowOtp(false);
                setError('');
              }}
              className="flex items-center gap-1 text-zinc-400 transition-colors hover:text-white"
            >
              <ArrowLeft size={14} /> Back
            </button>
            <button onClick={handleResend} className="text-purple-400 hover:underline">
              Resend code
            </button>
          </div>
        </motion.div>
      </AuthShell>
    );
  }

  // ===== Login / Register =====
  return (
    <AuthShell>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full">
        {/* Header */}
        <div className="text-center">
          <div className="mb-3 flex justify-center">
            <WindowsLogo size={64} className="drop-shadow-[0_0_30px_rgba(139,92,246,0.4)]" />
          </div>
          <h1 className="gradient-text animate-gradient text-3xl font-black tracking-tight">
            WINDOWS 12
          </h1>
          <p className="mt-1 text-xs uppercase tracking-[0.3em] text-zinc-600">Unofficial</p>
        </div>

        {/* Social buttons */}
        <div className="mt-8 flex gap-3">
          <button
            onClick={handleGoogle}
            className="glass-card flex flex-1 items-center justify-center gap-2 rounded-xl py-3 text-sm font-medium text-white transition-colors hover:bg-white/10"
          >
            <GoogleIcon className="h-5 w-5" />
            Google
          </button>
          <button
            onClick={handleApple}
            className="glass-card flex flex-1 items-center justify-center gap-2 rounded-xl py-3 text-sm font-medium text-white transition-colors hover:bg-white/10"
          >
            <AppleIcon className="h-5 w-5" />
            Apple
          </button>
        </div>

        {/* Divider */}
        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-white/10" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-[#0A0A0F] px-3 text-zinc-600">or</span>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="mb-4 rounded-lg border border-red-500/20 bg-red-500/10 p-3 text-sm text-red-400">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={mode === 'login' ? handleLogin : handleRegister} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-zinc-400">
              Email
            </Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
              <Input
                id="email"
                type="email"
                autoComplete="email"
                autoFocus
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="border-white/10 bg-white/[0.03] pl-10"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="auth-password" className="text-zinc-400">
              Password
            </Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 h-4 w-4 text-zinc-500" />
              <Input
                id="auth-password"
                type="password"
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="border-white/10 bg-white/[0.03] pl-10"
                required
              />
            </div>
          </div>

          {mode === 'register' && (
            <div className="space-y-2">
              <Label htmlFor="auth-confirm" className="text-zinc-400">
                Confirm Password
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 text-zinc-500" />
                <Input
                  id="auth-confirm"
                  type="password"
                  autoComplete="new-password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="border-white/10 bg-white/[0.03] pl-10"
                  required
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="gradient-bg flex w-full items-center justify-center gap-2 rounded-xl py-3 font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
          >
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            {loading
              ? mode === 'login'
                ? 'Signing in…'
                : 'Creating account…'
              : mode === 'login'
                ? 'Sign In'
                : 'Create Account'}
          </button>
        </form>

        {/* Toggle login/register */}
        <p className="mt-6 text-center text-sm text-zinc-500">
          {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
          <button
            onClick={() => {
              setMode(mode === 'login' ? 'register' : 'login');
              setError('');
            }}
            className="font-medium text-purple-400 hover:underline"
          >
            {mode === 'login' ? 'Create one' : 'Sign in'}
          </button>
        </p>

        {/* Guest */}
        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-white/10" />
          </div>
        </div>
        <button
          onClick={handleGuest}
          className="w-full rounded-xl border border-white/10 bg-white/[0.02] py-3 text-sm font-medium text-zinc-400 transition-colors hover:bg-white/5 hover:text-white"
        >
          Continue as Guest
        </button>
        <p className="mt-2 text-center text-xs text-zinc-600">
          Guests can browse but cannot download Windows 12
        </p>
      </motion.div>
    </AuthShell>
  );
}

function AuthShell({ children }) {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#0A0A0F] px-4">
      {/* Background orbs */}
      <div className="pointer-events-none absolute inset-0">
        <div className="animate-float absolute -left-20 top-1/4 h-[400px] w-[400px] rounded-full bg-blue-600/15 blur-[100px]" />
        <div className="animate-float absolute bottom-1/4 right-0 h-[400px] w-[400px] rounded-full bg-pink-600/15 blur-[100px] [animation-delay:2s]" />
        <div className="animate-float absolute left-1/3 top-1/2 h-[300px] w-[300px] -translate-y-1/2 rounded-full bg-purple-600/15 blur-[80px] [animation-delay:4s]" />
      </div>

      <div className="glass-card relative z-10 w-full max-w-md rounded-3xl p-8 md:p-10">{children}</div>
    </div>
  );
}